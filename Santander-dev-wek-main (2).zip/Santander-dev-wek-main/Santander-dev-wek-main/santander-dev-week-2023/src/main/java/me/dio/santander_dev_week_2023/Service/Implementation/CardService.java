package me.dio.santander_dev_week_2023.Service.Implementation;

import me.dio.santander_dev_week_2023.DTO.Read.CardResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.CardRequestDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.ICardService;

public class CardService implements ICardService {


    /**
     * @param id
     * @return
     */
    @Override
    public CardResponseDTO getCard(Long id) {
        return null;
    }

    /**
     * @param newCard
     * @return
     */
    @Override
    public Long create(CardResponseDTO newCard) {
        return null;
    }

    @Override
    public void delete(Long id) {

    }
}
