package me.dio.santander_dev_week_2023.DTO.Write;

import java.time.LocalDateTime;

public class NewsRequestDTO {

    public Long id;

    public String title;

    public String content;

    public LocalDateTime publicationDate;
}
