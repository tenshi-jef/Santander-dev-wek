package me.dio.santander_dev_week_2023.DTO.Write;

import java.math.BigDecimal;

public class CardRequestDTO {
    public Long id;

    public Long contaId;

    public String numero;

    public BigDecimal limite;

    private int codigoSeguranca;

    private boolean bloqueado;
    }