package me.dio.santander_dev_week_2023.Enums;

public enum PaymentEnum {
    DEBITO,
    CREDITO,
    PIX
}
