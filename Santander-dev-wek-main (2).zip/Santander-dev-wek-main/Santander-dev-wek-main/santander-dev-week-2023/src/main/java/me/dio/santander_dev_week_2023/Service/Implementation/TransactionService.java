package me.dio.santander_dev_week_2023.Service.Implementation;

import me.dio.santander_dev_week_2023.DTO.Read.TransactionResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Read.UserResponseDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.ITransactionService;

import java.util.ArrayList;

public class TransactionService implements ITransactionService {


    /**
     * @return
     */
    @Override
    public ArrayList<TransactionResponseDTO> getTransactions() {
        return null;
    }
}
