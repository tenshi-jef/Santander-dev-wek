package me.dio.santander_dev_week_2023.DTO.Write;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
@AllArgsConstructor
@Data
public class TransactionRequestDTO {

    public Long contaOrigemId;
    public Long contaDestinoId;
    public BigDecimal valor;
}