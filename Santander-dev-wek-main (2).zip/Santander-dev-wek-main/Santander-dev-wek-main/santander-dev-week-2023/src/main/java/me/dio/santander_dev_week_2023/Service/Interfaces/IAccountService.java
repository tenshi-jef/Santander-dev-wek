package me.dio.santander_dev_week_2023.Service.Interfaces;

import me.dio.santander_dev_week_2023.DTO.Read.AccountResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Read.UserResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.AccountRequestDTO;
import me.dio.santander_dev_week_2023.DTO.Write.UserRequestDTO;

import java.util.ArrayList;

public interface IAccountService {

    public AccountResponseDTO getAccount(Long id);

    public Long create(AccountRequestDTO newAccount);

    public Long update(Long id);

    void delete (Long id);
}
