package me.dio.santander_dev_week_2023.Controller;

import io.swagger.v3.oas.annotations.Operation;
import me.dio.santander_dev_week_2023.Service.Implementation.UserService;
import me.dio.santander_dev_week_2023.Service.Interfaces.IAccountService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class AccountController {
    private final IAccountService service;

    public AccountController(IAccountService service) {
        this.service = service;
    }


    @GetMapping("{id}")
    @Operation(summary = "Buscar Cartao por id ")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Quando nenhum resultado é encontrado")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "quando retorna resultado")
    public ResponseEntity<Object> BuscarCartao(@RequestParam Long id)
    {
        var result = service.getAccount(id);
        return ResponseEntity.ok(result);

    }
}
