package me.dio.santander_dev_week_2023.Service.Implementation;

import me.dio.santander_dev_week_2023.DTO.Read.AccountResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.AccountRequestDTO;
import me.dio.santander_dev_week_2023.DTO.Write.UserRequestDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.IAccountService;

public class AccountService implements IAccountService {


    /**
     * @param id
     * @return
     */
    @Override
    public AccountResponseDTO getAccount(Long id) {
        return null;
    }

    /**
     * @param newAccount
     * @return
     */
    @Override
    public Long create(AccountRequestDTO newAccount) {
        return null;
    }

    /**
     * @param id
     * @return
     */
    @Override
    public Long update(Long id) {
        return null;
    }

    /**
     * @param id
     */
    @Override
    public void delete(Long id) {

    }
}
