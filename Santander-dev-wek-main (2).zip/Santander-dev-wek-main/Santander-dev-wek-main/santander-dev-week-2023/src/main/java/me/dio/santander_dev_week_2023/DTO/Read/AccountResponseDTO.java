package me.dio.santander_dev_week_2023.DTO.Read;

import java.math.BigDecimal;

public class AccountResponseDTO {
    public Long id;

    public Long usuarioId;

    public String numero;

    public BigDecimal saldo;

    private int codigoSeguranca;

    private boolean bloqueado;
}