package me.dio.santander_dev_week_2023.Service.Implementation;

import me.dio.santander_dev_week_2023.DTO.Read.NewsResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Read.UserResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.NewsRequestDTO;
import me.dio.santander_dev_week_2023.DTO.Write.UserRequestDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.INewsService;

import java.util.ArrayList;

public class NewsService implements INewsService {


    /**
     * @return
     */
    @Override
    public ArrayList<NewsResponseDTO> getNews() {
        return null;
    }

    /**
     * @param id
     * @return
     */
    @Override
    public NewsResponseDTO getNew(Long id) {
        return null;
    }

    /**
     * @param newNews
     * @return
     */
    @Override
    public Long create(NewsRequestDTO newNews) {
        return 0L;
    }

    /**
     * @param id
     * @return
     */
    @Override
    public Long update(Long id) {
        return 0L;
    }

    /**
     * @param id
     */
    @Override
    public void delete(Long id) {

    }
}
