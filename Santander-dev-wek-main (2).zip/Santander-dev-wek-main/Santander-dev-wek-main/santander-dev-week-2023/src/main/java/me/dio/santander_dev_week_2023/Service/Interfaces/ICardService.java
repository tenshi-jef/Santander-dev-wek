package me.dio.santander_dev_week_2023.Service.Interfaces;

import me.dio.santander_dev_week_2023.DTO.Read.CardResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.CardRequestDTO;

public interface ICardService {
    public CardResponseDTO getCard(Long id);

    public Long create(CardResponseDTO newCard);

    void delete(Long id);
}
