package me.dio.santander_dev_week_2023.Service.Interfaces;

import me.dio.santander_dev_week_2023.DTO.Read.TransactionResponseDTO;

import java.util.ArrayList;

public interface ITransactionService {
     ArrayList<TransactionResponseDTO> getTransactions();
}
