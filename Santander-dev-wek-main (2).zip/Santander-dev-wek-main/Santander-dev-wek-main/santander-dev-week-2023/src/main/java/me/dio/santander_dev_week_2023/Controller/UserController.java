package me.dio.santander_dev_week_2023.Controller;

import io.swagger.v3.oas.annotations.Operation;
import me.dio.santander_dev_week_2023.DTO.Write.UserRequestDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.IUserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("v1/usuario")
public class UserController {

    private final IUserService userService;

    public UserController(IUserService userService) {
        this.userService = userService;
    }

    @GetMapping
    @Operation(summary = "Buscar usuario por id ")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Quando nenhum resultado é encontrado")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "quando retorna resultado")
    public ResponseEntity<Object> BuscarUsuarios()
    {
        var result = userService.getUsers();
        return ResponseEntity.ok(result);

    }

    @GetMapping("{id}")
    @Operation(summary = "Buscar usuario por id ")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Quando nenhum resultado é encontrado")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "quando retorna resultado")
    public ResponseEntity<Object> BuscarUsuario(@RequestParam Long id)
    {
        var result = userService.getUser(id);
        return ResponseEntity.ok(result);

    }


    @PostMapping
    @Operation(summary = "Criar um novo usuário")
    public ResponseEntity<Long> CriarUsuario(@RequestBody UserRequestDTO dto) {
        var id = userService.create(dto);
        return ResponseEntity.ok(id);

    }

    @PutMapping("{id}")
    @Operation(summary = "Atualizar usuário existente")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Usuário atualizado com sucesso")
    public ResponseEntity<Object> AtualizarUsuario(@PathVariable Long id, @RequestBody UserRequestDTO usuarioAtualizado) {
        var idAtualizado = userService.update(id);
        return ResponseEntity.ok(idAtualizado);
    }


    @DeleteMapping("{id}")
    @Operation(summary = "Deletar usuário por id")
    @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "204", description = "Usuário deletado com sucesso")
    public ResponseEntity<Object> DeletarUsuario(@PathVariable Long id) {
        userService.delete(id);
        return ResponseEntity.noContent().build();
    }

    }