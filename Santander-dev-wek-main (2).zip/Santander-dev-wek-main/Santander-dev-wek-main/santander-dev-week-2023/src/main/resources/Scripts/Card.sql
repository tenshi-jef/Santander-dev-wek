INSERT INTO tb_cartao (conta_id, numero, limite, codigoSeguranca, bloqueado) VALUES
 (1, '4111111111111111', 5000.00, 123, false),
 (2, '5500000000000004', 3000.00, 456, false),
 (3, '340000000000009', 1000.00, 789, true),
 (4, '30000000000004', 1500.00, 321, false),
 (5, '6011000000000004', 7000.00, 654, true);