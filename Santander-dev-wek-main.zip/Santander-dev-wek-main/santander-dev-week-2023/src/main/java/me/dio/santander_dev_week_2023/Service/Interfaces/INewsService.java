package me.dio.santander_dev_week_2023.Service.Interfaces;

public interface INewsService {
}
