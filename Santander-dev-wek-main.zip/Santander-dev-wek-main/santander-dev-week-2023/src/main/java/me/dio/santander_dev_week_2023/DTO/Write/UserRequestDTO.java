package me.dio.santander_dev_week_2023.DTO.Write;

import lombok.Data;

@Data
    public class UserRequestDTO {

    public  String nome;
    public String email;
    public String senha;
}

