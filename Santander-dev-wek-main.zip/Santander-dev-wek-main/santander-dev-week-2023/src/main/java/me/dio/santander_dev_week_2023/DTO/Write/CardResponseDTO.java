package me.dio.santander_dev_week_2023.DTO.Write;

import jakarta.persistence.Column;

import java.math.BigDecimal;

public class CardResponseDTO {

       public Long id;

     public Long contaId;

     public String numero;

     public BigDecimal limite;

    private int codigoSeguranca;

    private boolean bloqueado;

    }