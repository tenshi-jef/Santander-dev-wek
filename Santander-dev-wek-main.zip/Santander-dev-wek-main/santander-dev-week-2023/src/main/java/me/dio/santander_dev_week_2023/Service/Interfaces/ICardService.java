package me.dio.santander_dev_week_2023.Service.Interfaces;

import me.dio.santander_dev_week_2023.DTO.Read.CardRequestDTO;
import me.dio.santander_dev_week_2023.DTO.Read.UserResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.CardResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.UserRequestDTO;

public interface ICardService {
    public CardResponseDTO getCard(Long id);

    public Long create(CardRequestDTO newUser);

}
