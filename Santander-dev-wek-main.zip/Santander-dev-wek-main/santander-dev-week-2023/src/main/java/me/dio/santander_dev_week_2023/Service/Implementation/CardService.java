package me.dio.santander_dev_week_2023.Service.Implementation;

import me.dio.santander_dev_week_2023.DTO.Read.CardRequestDTO;
import me.dio.santander_dev_week_2023.DTO.Write.CardResponseDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.ICardService;

public class CardService implements ICardService {


    /**
     * @param id
     * @return
     */
    @Override
    public CardResponseDTO getCard(Long id) {
        return null;
    }

    /**
     * @param newUser
     * @return
     */
    @Override
    public Long create(CardRequestDTO newUser) {
        return null;
    }
}
