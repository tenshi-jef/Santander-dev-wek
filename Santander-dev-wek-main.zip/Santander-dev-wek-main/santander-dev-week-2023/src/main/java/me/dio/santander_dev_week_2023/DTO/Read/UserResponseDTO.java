package me.dio.santander_dev_week_2023.DTO.Read;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class UserResponseDTO {

    public Long id;
    public String cpf;
    public String nome;
    public String email;
}
