package me.dio.santander_dev_week_2023.DTO.Write;

import java.math.BigDecimal;

public class PaymentRequestDTO{
    public  Long contaId;
    public BigDecimal valor;
    public  String descricao;
}