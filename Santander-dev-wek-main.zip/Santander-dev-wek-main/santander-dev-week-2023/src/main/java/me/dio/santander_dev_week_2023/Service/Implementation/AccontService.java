package me.dio.santander_dev_week_2023.Service.Implementation;

import me.dio.santander_dev_week_2023.DTO.Read.AccountResponseDTO;
import me.dio.santander_dev_week_2023.DTO.Write.UserRequestDTO;
import me.dio.santander_dev_week_2023.Service.Interfaces.IAccountService;

public class AccontService implements IAccountService {


    /**
     * @param id
     * @return
     */
    @Override
    public AccountResponseDTO getAccount(Long id) {
        return null;
    }

    /**
     * @param newUser
     * @return
     */
    @Override
    public Long create(UserRequestDTO newUser) {
        return null;
    }

    /**
     * @param id
     * @return
     */
    @Override
    public Long update(Long id) {
        return null;
    }
}
