package me.dio.santander_dev_week_2023.Controller;

public class NewsController {
}
