INSERT INTO tb_conta (usuario_id, numero, saldo) VALUES
(1, '0001', 1500.00),
(2, '0002', 3200.50),
(3, '0003', 980.75),
(4, '0004', 250.00),
(5, '0005', 7650.20);
