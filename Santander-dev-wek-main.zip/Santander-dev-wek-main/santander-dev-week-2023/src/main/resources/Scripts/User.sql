INSERT INTO TB_USUARIO (CPF, EMAIL, NOME, SENHA) VALUES
('123.456.789-00', 'joao.silva@email.com', 'João Silva', 'senha123'),
('987.654.321-00', 'maria.souza@email.com', 'Maria Souza', 'abc@456'),
('456.789.123-00', 'carlos.lima@email.com', 'Carlos Lima', 'qwe!789'),
('321.654.987-00', 'ana.pereira@email.com', 'Ana Pereira', 'zxc#321'),
('159.753.486-00', 'lucas.mendes@email.com', 'Lucas Mendes', 'lucas@2024');